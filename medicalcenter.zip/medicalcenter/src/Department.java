public class Department {
    private final int id;
    private final String name;
    private int numEmployees;
    private MedicalServiceCardiology cardiology;
    private MedicalServiceDermatology dermatology;
    private MedicalServiceGynecology gynecology;
    private MedicalServiceNeurology neurology;
    private MedicalServiceOncology oncology;

    public Department(int id, String name, int numEmployees, MedicalServiceCardiology cardiology, MedicalServiceDermatology dermatology, MedicalServiceGynecology gynecology, MedicalServiceNeurology neurology, MedicalServiceOncology oncology) {
        this.id = id;
        this.name = name;
        this.numEmployees = numEmployees;
        this.cardiology = cardiology;
        this.dermatology = dermatology;
        this.gynecology = gynecology;
        this.neurology = neurology;
        this.oncology = oncology;
    }


    public int getId() {
        return id;
    }

    public String getName() {
        return name;
    }

    public int getNumEmployees() {
        return numEmployees;
    }


    public class MedicalServiceCardiology {

    }

    public class MedicalServiceDermatology {

    }

    public class MedicalServiceGynecology {

    }

    public class MedicalServiceNeurology {

    }

    public class MedicalServiceOncology {

    }
}
}
